package com.example.olddialer

import android.content.Context

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    fun autoRecord(ctx: Context) = p(ctx).getBoolean("auto_rec", false)
    fun setAutoRecord(ctx: Context, on: Boolean) = p(ctx).edit().putBoolean("auto_rec", on).apply()
}
