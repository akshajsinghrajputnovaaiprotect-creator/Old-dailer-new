package com.example.olddialer

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Call recording. Android third-party apps ko call ki awaaz seedhe nahi deta,
 * isliye mic se record hota hai (samne wale ki awaaz ke liye speaker on rakho).
 * Files: Music/CallRecordings/ (MediaStore).
 */
object CallRecorder {
    const val FOLDER = "Music/CallRecordings"
    private var rec: MediaRecorder? = null
    private var uri: Uri? = null
    var startedAt = 0L
        private set
    val isRecording: Boolean get() = rec != null

    private fun safe(s: String): String {
        val t = s.filter { it.isLetterOrDigit() || it == '+' }.take(24)
        return if (t.isEmpty()) "Unknown" else t
    }

    fun start(ctx: Context, who: String): Boolean {
        if (rec != null) return true
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, "${safe(who)}_$stamp.m4a")
            put(MediaStore.Audio.Media.TITLE, who)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, FOLDER)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val u = try {
            ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
        } catch (e: Exception) { null } ?: return false

        for (src in intArrayOf(MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.VOICE_RECOGNITION)) {
            val pfd = try { ctx.contentResolver.openFileDescriptor(u, "w") } catch (e: Exception) { null } ?: break
            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else MediaRecorder()
            try {
                r.setAudioSource(src)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioSamplingRate(44100)
                r.setAudioEncodingBitRate(128000)
                r.setOutputFile(pfd.fileDescriptor)
                r.prepare()
                r.start()
                pfd.close()
                rec = r; uri = u; startedAt = System.currentTimeMillis()
                return true
            } catch (e: Exception) {
                try { r.release() } catch (x: Exception) { }
                try { pfd.close() } catch (x: Exception) { }
            }
        }
        try { ctx.contentResolver.delete(u, null, null) } catch (e: Exception) { }
        return false
    }

    /** true = file save ho gayi. */
    fun stop(ctx: Context): Boolean {
        val r = rec ?: return false
        val u = uri
        rec = null; uri = null
        var ok = true
        try { r.stop() } catch (e: RuntimeException) { ok = false } // bahut chhoti recording
        try { r.release() } catch (e: Exception) { }
        if (u != null) {
            try {
                if (ok) {
                    ctx.contentResolver.update(
                        u, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null
                    )
                } else ctx.contentResolver.delete(u, null, null)
            } catch (e: Exception) { }
        }
        return ok
    }
}
