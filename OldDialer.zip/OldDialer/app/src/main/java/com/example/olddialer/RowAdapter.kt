package com.example.olddialer

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat

/** kind: 0 normal, 1 incoming, 2 outgoing, 3 missed, 4 rejected */
data class Row(
    val title: String, val sub: String, val number: String,
    val kind: Int = 0, val time: String = ""
)

class RowAdapter(ctx: Context, rows: List<Row>) : ArrayAdapter<Row>(ctx, 0, rows) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView
            ?: LayoutInflater.from(context).inflate(R.layout.item_row, parent, false)
        val r = getItem(position)
        val title = r?.title ?: ""
        val av = v.findViewById<TextView>(R.id.avatar)
        av.text = Ui.initial(title)
        av.background = Ui.avatarBg(title)
        val t = v.findViewById<TextView>(R.id.rowTitle)
        t.text = title
        val missed = r?.kind == 3 || r?.kind == 4
        t.setTextColor(ContextCompat.getColor(context, if (missed) R.color.c_red else R.color.c_text))
        val sub = v.findViewById<TextView>(R.id.rowSub)
        sub.text = r?.sub ?: ""
        sub.visibility = if (r?.sub.isNullOrEmpty()) View.GONE else View.VISIBLE
        sub.setTextColor(ContextCompat.getColor(context, if (missed) R.color.c_red else R.color.c_sub))
        v.findViewById<TextView>(R.id.rowTime).text = r?.time ?: ""
        return v
    }
}
