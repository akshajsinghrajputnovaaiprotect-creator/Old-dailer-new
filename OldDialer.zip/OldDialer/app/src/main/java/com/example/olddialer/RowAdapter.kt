package com.example.olddialer

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

/** kind: 0 normal, 1 incoming, 2 outgoing, 3 missed, 4 rejected */
data class Row(val title: String, val sub: String, val number: String, val kind: Int = 0)

class RowAdapter(ctx: Context, rows: List<Row>) : ArrayAdapter<Row>(ctx, 0, rows) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView
            ?: LayoutInflater.from(context).inflate(R.layout.item_row, parent, false)
        val r = getItem(position)
        val title = r?.title ?: ""
        val av = v.findViewById<TextView>(R.id.avatar)
        av.text = Ui.initial(title)
        av.background = Ui.avatarBg(title)
        v.findViewById<TextView>(R.id.rowTitle).text = title
        val sub = v.findViewById<TextView>(R.id.rowSub)
        sub.text = r?.sub ?: ""
        sub.setTextColor(
            when (r?.kind) {
                3, 4 -> 0xFFFF5C7A.toInt()
                1 -> 0xFF7CF7FF.toInt()
                2 -> 0xFFB6FF3B.toInt()
                else -> 0xFFB0A8D8.toInt()
            }
        )
        return v
    }
}
