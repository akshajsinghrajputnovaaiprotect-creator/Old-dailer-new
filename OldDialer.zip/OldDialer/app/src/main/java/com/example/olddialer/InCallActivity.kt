package com.example.olddialer

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InCallActivity : AppCompatActivity() {
    private lateinit var number: TextView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var ringRow: View
    private lateinit var activeRow: View
    private var muted = false
    private var speaker = false
    private val handler = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { render() }
    private val ticker = object : Runnable {
        override fun run() { updateTimer(); handler.postDelayed(this, 1000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_in_call)
        number = findViewById(R.id.callNumber)
        status = findViewById(R.id.callStatus)
        timer = findViewById(R.id.callTimer)
        ringRow = findViewById(R.id.ringRow)
        activeRow = findViewById(R.id.activeRow)

        findViewById<Button>(R.id.btnAnswer).setOnClickListener { CallManager.answer() }
        findViewById<Button>(R.id.btnReject).setOnClickListener { CallManager.reject() }
        findViewById<Button>(R.id.btnEnd).setOnClickListener { CallManager.hangup() }
        findViewById<Button>(R.id.btnMute).setOnClickListener {
            muted = !muted; CallManager.mute(muted)
            (it as Button).text = if (muted) "Unmute" else "Mute"
        }
        findViewById<Button>(R.id.btnSpeaker).setOnClickListener {
            speaker = !speaker; CallManager.speaker(speaker)
            (it as Button).text = if (speaker) "Earpiece" else "Speaker"
        }
    }

    override fun onStart() {
        super.onStart()
        CallManager.addListener(listener)
        render()
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        CallManager.removeListener(listener)
        handler.removeCallbacks(ticker)
    }

    private fun render() {
        val c = CallManager.call
        if (c == null) { finish(); return }
        number.text = CallManager.number()
        val ringing = c.state == Call.STATE_RINGING
        ringRow.visibility = if (ringing) View.VISIBLE else View.GONE
        activeRow.visibility = if (ringing) View.GONE else View.VISIBLE
        status.text = when (c.state) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling..."
            Call.STATE_ACTIVE -> "Connected"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Call ended"
            else -> ""
        }
        if (c.state == Call.STATE_DISCONNECTED) handler.postDelayed({ finish() }, 700)
        updateTimer()
    }

    private fun updateTimer() {
        val c = CallManager.call
        if (c == null || c.state != Call.STATE_ACTIVE) { timer.text = ""; return }
        val start = c.details.connectTimeMillis
        val s = ((System.currentTimeMillis() - start) / 1000).coerceAtLeast(0)
        timer.text = "%02d:%02d".format(s / 60, s % 60)
    }
}
