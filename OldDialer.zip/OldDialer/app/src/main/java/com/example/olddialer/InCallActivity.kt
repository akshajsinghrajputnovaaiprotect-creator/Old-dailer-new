package com.example.olddialer

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Samsung One UI style call screen: pastel background, timer on top, controls in a rounded card. */
class InCallActivity : AppCompatActivity() {
    private lateinit var root: View
    private lateinit var avatarBox: View
    private lateinit var avatar: TextView
    private lateinit var callNumber: TextView
    private lateinit var callSub: TextView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var dtmfText: TextView
    private lateinit var keypadPanel: LinearLayout
    private lateinit var callCard: View
    private lateinit var ringRow: View
    private lateinit var btnAnswer: View
    private lateinit var btnMute: ImageView
    private lateinit var btnSpeaker: ImageView
    private lateinit var btnKeypad: ImageView
    private lateinit var btnHold: ImageView
    private lateinit var btnBt: ImageView
    private lateinit var btnAdd: ImageView
    private lateinit var spacer: View
    private lateinit var btnRec: TextView
    private lateinit var rings: List<View>

    private var muted = false
    private var speaker = false
    private var bluetooth = false
    private var keypadOn = false
    private var lastBg = -1
    private var nameFor: String? = null
    private var nameKey: String? = null
    private var pulseOn = false
    private var bounce: ObjectAnimator? = null
    private val pulses = mutableListOf<ValueAnimator>()
    private val recPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) toggleRec() else Toast.makeText(this, "Mic permission chahiye", Toast.LENGTH_SHORT).show()
        }
    private val handler = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { render() }
    private val ticker = object : Runnable {
        override fun run() { updateTimer(); handler.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun textColor() = ContextCompat.getColor(this, R.color.c_call_text)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        setContentView(R.layout.activity_in_call)
        root = findViewById(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom)
            insets
        }
        avatarBox = findViewById(R.id.avatarBox)
        avatar = findViewById(R.id.avatar)
        callNumber = findViewById(R.id.callNumber)
        callSub = findViewById(R.id.callSub)
        status = findViewById(R.id.callStatus)
        timer = findViewById(R.id.callTimer)
        dtmfText = findViewById(R.id.dtmfText)
        keypadPanel = findViewById(R.id.keypadPanel)
        callCard = findViewById(R.id.callCard)
        ringRow = findViewById(R.id.ringRow)
        btnAnswer = findViewById(R.id.btnAnswer)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)
        btnKeypad = findViewById(R.id.btnKeypad)
        btnHold = findViewById(R.id.btnHold)
        btnBt = findViewById(R.id.btnBt)
        btnAdd = findViewById(R.id.btnAdd)
        spacer = findViewById(R.id.spacer)
        btnRec = findViewById(R.id.btnRec)
        btnRec.setOnClickListener { toggleRec() }
        rings = listOf(findViewById(R.id.ring1), findViewById(R.id.ring2), findViewById(R.id.ring3))

        btnAnswer.setOnClickListener { it.pop(); CallManager.answer() }
        findViewById<View>(R.id.btnReject).setOnClickListener { it.pop(); CallManager.reject() }
        findViewById<View>(R.id.btnEnd).setOnClickListener { it.pop(); CallManager.hangup() }
        btnMute.setOnClickListener {
            muted = !muted; CallManager.mute(muted); styleToggle(btnMute, muted)
        }
        btnSpeaker.setOnClickListener {
            speaker = !speaker
            if (speaker && bluetooth) { bluetooth = false; styleToggle(btnBt, false) }
            CallManager.speaker(speaker); styleToggle(btnSpeaker, speaker)
        }
        btnBt.setOnClickListener {
            val want = !bluetooth
            if (!CallManager.bluetooth(want)) {
                Toast.makeText(this, "Koi Bluetooth device connected nahi", Toast.LENGTH_SHORT).show()
            } else {
                bluetooth = want
                if (want && speaker) { speaker = false; styleToggle(btnSpeaker, false) }
                styleToggle(btnBt, bluetooth)
            }
        }
        btnKeypad.setOnClickListener {
            keypadOn = !keypadOn; styleToggle(btnKeypad, keypadOn)
            keypadPanel.visibility = if (keypadOn) View.VISIBLE else View.GONE
            avatarBox.visibility = if (keypadOn) View.GONE else View.VISIBLE
            spacer.visibility = if (keypadOn) View.VISIBLE else View.GONE
        }
        btnHold.setOnClickListener {
            val holding = CallManager.call?.state == Call.STATE_HOLDING
            CallManager.hold(!holding)
        }
        btnAdd.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        findViewById<View>(R.id.btnCallMore).setOnClickListener { v ->
            PopupMenu(this, v).apply {
                menu.add(0, 1, 0, "Message")
                menu.add(0, 2, 1, if (CallRecorder.isRecording) "Stop recording" else "Record call")
                menu.add(0, 3, 2, "Call recordings")
                setOnMenuItemClickListener {
                    when (it.itemId) {
                        1 -> startActivity(
                            Intent(this@InCallActivity, ThreadActivity::class.java)
                                .putExtra("address", CallManager.number())
                        )
                        2 -> toggleRec()
                        3 -> startActivity(Intent(this@InCallActivity, RecordingsActivity::class.java))
                    }
                    true
                }
                show()
            }
        }
        findViewById<View>(R.id.btnQuickMsg).setOnClickListener { v ->
            PopupMenu(this, v).apply {
                val replies = listOf(
                    "I can't talk right now. What's up?",
                    "I'll call you back in a bit.",
                    "Can you text me instead?"
                )
                replies.forEachIndexed { i, r -> menu.add(0, i, i, r) }
                setOnMenuItemClickListener { CallManager.reject(replies[it.itemId]); true }
                show()
            }
        }
        for (b in listOf(btnMute, btnSpeaker, btnBt, btnKeypad, btnHold, btnAdd)) styleToggle(b, false)
        buildKeypad()
    }

    /** Off: sirf dark icon. On: gol dark background + white icon (One UI jaisa). */
    private fun styleToggle(v: ImageView, on: Boolean) {
        if (on) {
            v.setBackgroundResource(R.drawable.bg_call_btn_on)
            v.setColorFilter(Color.WHITE)
        } else {
            v.background = null
            v.setColorFilter(textColor())
        }
    }

    private fun buildKeypad() {
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (k in keys.subList(r * 3, r * 3 + 3)) {
                val tv = TextView(this)
                tv.text = k
                tv.textSize = 24f
                tv.setTextColor(textColor())
                tv.gravity = Gravity.CENTER
                tv.setBackgroundResource(R.drawable.bg_call_btn)
                val lp = LinearLayout.LayoutParams(dp(58), dp(58))
                lp.setMargins(dp(10), dp(4), dp(10), dp(4))
                tv.layoutParams = lp
                tv.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            CallManager.call?.playDtmfTone(k[0])
                            dtmfText.append(k)
                            v.pop()
                            true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            CallManager.call?.stopDtmfTone()
                            true
                        }
                        else -> false
                    }
                }
                row.addView(tv)
            }
            keypadPanel.addView(row)
        }
    }

    override fun onStart() {
        super.onStart()
        CallManager.addListener(listener)
        render()
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        CallManager.removeListener(listener)
        handler.removeCallbacks(ticker)
        setPulse(false)
        setBounce(false)
    }

    /** Pulse rings sirf incoming call par. */
    private fun setPulse(on: Boolean) {
        if (pulseOn == on && (!on || pulses.isNotEmpty())) return
        pulseOn = on
        pulses.forEach { it.cancel() }
        pulses.clear()
        rings.forEach { it.alpha = 0f }
        if (!on) return
        rings.forEachIndexed { i, v ->
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.duration = 2400L
            a.repeatCount = ValueAnimator.INFINITE
            a.startDelay = i * 800L
            a.interpolator = LinearInterpolator()
            a.addUpdateListener {
                val t = it.animatedValue as Float
                v.scaleX = 1f + t * 0.9f
                v.scaleY = 1f + t * 0.9f
                v.alpha = 0.6f * (1f - t)
            }
            a.start()
            pulses.add(a)
        }
    }

    private fun setBounce(on: Boolean) {
        if (on == (bounce != null)) return
        bounce?.cancel()
        bounce = null
        btnAnswer.translationY = 0f
        if (on) {
            val a = ObjectAnimator.ofFloat(btnAnswer, View.TRANSLATION_Y, 0f, -24f)
            a.duration = 550
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.interpolator = AccelerateDecelerateInterpolator()
            a.start()
            bounce = a
        }
    }

    private fun setBg(res: Int) {
        if (lastBg == res) return
        lastBg = res
        root.setBackgroundResource(res)
    }

    private fun render() {
        val c = CallManager.call
        if (c == null) { finish(); return }
        val num = CallManager.number()
        if (nameKey != num) { nameKey = num; nameFor = ContactUtils.nameFor(this, num) }
        val name = nameFor
        callNumber.text = name ?: num
        callSub.text = if (name != null) num else ""
        callSub.visibility = if (name != null) View.VISIBLE else View.GONE
        if (name != null && Ui.hasLetter(name)) {
            avatar.text = Ui.initial(name)
            avatar.background = Ui.avatarBg(name)
        } else {
            avatar.text = ""
            avatar.setBackgroundResource(R.drawable.bg_avatar_default)
        }

        val ringing = c.state == Call.STATE_RINGING
        ringRow.visibility = if (ringing) View.VISIBLE else View.GONE
        callCard.visibility = if (ringing) View.GONE else View.VISIBLE
        avatar.visibility = if (ringing) View.VISIBLE else View.INVISIBLE
        setBounce(ringing)
        setPulse(ringing)
        styleToggle(btnHold, c.state == Call.STATE_HOLDING)

        when (c.state) {
            Call.STATE_RINGING -> { setBg(R.drawable.bg_call_ring); status.text = "Incoming call" }
            Call.STATE_DIALING, Call.STATE_CONNECTING -> { setBg(R.drawable.bg_call_ring); status.text = "Calling…" }
            Call.STATE_ACTIVE -> { setBg(R.drawable.bg_call_active); status.text = "" }
            Call.STATE_HOLDING -> { setBg(R.drawable.bg_call_active); status.text = "On hold" }
            else -> { setBg(R.drawable.bg_call_ended); status.text = "Call ended" }
        }
        status.visibility = if (status.text.isEmpty()) View.GONE else View.VISIBLE
        if (c.state == Call.STATE_DISCONNECTED) handler.postDelayed({ finish() }, 800)
        updateTimer()
    }

    private fun toggleRec() {
        if (CallRecorder.isRecording) {
            CallManager.stopRecording(this)
            Toast.makeText(this, "Recording save ho gayi", Toast.LENGTH_SHORT).show()
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                recPerm.launch(Manifest.permission.RECORD_AUDIO); return
            }
            if (CallManager.startRecording(this)) {
                if (!speaker && !bluetooth) {
                    Toast.makeText(this, "Samne wale ki awaaz ke liye speaker on rakho", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Recording start nahi ho payi", Toast.LENGTH_SHORT).show()
            }
        }
        updateRec()
    }

    private fun updateRec() {
        if (CallRecorder.isRecording) {
            val s = ((System.currentTimeMillis() - CallRecorder.startedAt) / 1000).coerceAtLeast(0)
            btnRec.text = "●  REC %02d:%02d".format(s / 60, s % 60)
            btnRec.setTextColor(ContextCompat.getColor(this, R.color.c_red))
        } else {
            btnRec.text = "●  Rec"
            btnRec.setTextColor(textColor())
        }
        btnRec.visibility = if (CallManager.call?.state == Call.STATE_RINGING) View.INVISIBLE else View.VISIBLE
    }

    private fun updateTimer() {
        updateRec()
        val c = CallManager.call
        if (c == null || c.state != Call.STATE_ACTIVE) { timer.text = ""; return }
        val start = c.details.connectTimeMillis
        val s = ((System.currentTimeMillis() - start) / 1000).coerceAtLeast(0)
        timer.text = "%02d:%02d".format(s / 60, s % 60)
    }
}
