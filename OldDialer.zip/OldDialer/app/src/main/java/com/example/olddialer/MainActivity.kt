package com.example.olddialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.view.View
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import java.text.DateFormat
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var brand: TextView
    private lateinit var numberBlock: View
    private lateinit var numberView: TextView
    private lateinit var suggestView: TextView
    private lateinit var btnBack: TextView
    private lateinit var dialPane: View
    private lateinit var historyPane: View
    private lateinit var contactsPane: View
    private lateinit var historyList: ListView
    private lateinit var contactsList: ListView
    private lateinit var chipAll: TextView
    private lateinit var chipMissed: TextView
    private lateinit var searchBox: EditText
    private lateinit var tabViews: List<TextView>

    private val number = StringBuilder()
    private var tab = 0
    private var missedOnly = false
    private var suggestion: Row? = null
    private var historyCache: List<Row> = emptyList()
    private var contactCache: List<Row> = emptyList()

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadContacts()
            if (tab == 1) loadHistory()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        brand = findViewById(R.id.brand)
        numberBlock = findViewById(R.id.numberBlock)
        numberView = findViewById(R.id.numberView)
        suggestView = findViewById(R.id.suggestView)
        btnBack = findViewById(R.id.btnBack)
        dialPane = findViewById(R.id.dialPane)
        historyPane = findViewById(R.id.historyPane)
        contactsPane = findViewById(R.id.contactsPane)
        historyList = findViewById(R.id.historyList)
        contactsList = findViewById(R.id.contactsList)
        chipAll = findViewById(R.id.chipAll)
        chipMissed = findViewById(R.id.chipMissed)
        searchBox = findViewById(R.id.searchBox)
        tabViews = listOf(
            findViewById(R.id.tabDial), findViewById(R.id.tabHistory), findViewById(R.id.tabContacts)
        )
        tabViews.forEachIndexed { i, t -> t.setOnClickListener { it.pop(); selectTab(i) } }

        findViewById<RotaryDialView>(R.id.dial).apply {
            onDigit = { append(it) }
            onCenterTap = { placeCall(number.toString()) }
        }
        btnBack.setOnClickListener {
            it.pop()
            if (number.isNotEmpty()) { number.deleteCharAt(number.length - 1); refresh() }
        }
        btnBack.setOnLongClickListener { number.clear(); refresh(); true }
        mapOf(R.id.btnStar to '*', R.id.btnHash to '#', R.id.btnPlus to '+').forEach { (id, ch) ->
            findViewById<View>(id).setOnClickListener { it.pop(); append(ch) }
        }
        findViewById<View>(R.id.btnCall).setOnClickListener { it.pop(); placeCall(number.toString()) }
        suggestView.setOnClickListener {
            suggestion?.let { number.clear(); number.append(it.number); refresh() }
        }

        chipAll.setOnClickListener { missedOnly = false; styleChips(); applyHistory() }
        chipMissed.setOnClickListener { missedOnly = true; styleChips(); applyHistory() }
        searchBox.doAfterTextChanged { applyContacts() }

        for (lv in listOf(historyList, contactsList)) {
            lv.setOnItemClickListener { _, _, pos, _ ->
                (lv.adapter as? RowAdapter)?.getItem(pos)?.let { placeCall(it.number) }
            }
            lv.setOnItemLongClickListener { _, _, pos, _ ->
                (lv.adapter as? RowAdapter)?.getItem(pos)?.let {
                    number.clear(); number.append(it.number); selectTab(0)
                }
                true
            }
        }

        permLauncher.launch(
            arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
        styleChips()
        selectTab(0)
        loadContacts()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (tab == 1) loadHistory()
    }

    private fun handleIntent(i: Intent?) {
        i?.data?.schemeSpecificPart?.let {
            number.clear(); number.append(Uri.decode(it)); selectTab(0)
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        dialPane.visibility = if (i == 0) View.VISIBLE else View.GONE
        historyPane.visibility = if (i == 1) View.VISIBLE else View.GONE
        contactsPane.visibility = if (i == 2) View.VISIBLE else View.GONE
        numberBlock.visibility = if (i == 0) View.VISIBLE else View.GONE
        brand.text = when (i) { 0 -> "OLD DIALER"; 1 -> "RECENTS"; else -> "PEOPLE" }
        tabViews.forEachIndexed { idx, t ->
            t.setBackgroundResource(if (idx == i) R.drawable.bg_tab_sel else 0)
        }
        val pane = when (i) { 0 -> dialPane; 1 -> historyPane; else -> contactsPane }
        pane.alpha = 0f
        pane.animate().alpha(1f).setDuration(220).start()
        refresh()
        if (i == 1) loadHistory()
        if (i == 2) applyContacts()
    }

    private fun styleChips() {
        chipAll.setBackgroundResource(if (!missedOnly) R.drawable.bg_chip_on else R.drawable.bg_chip_off)
        chipMissed.setBackgroundResource(if (missedOnly) R.drawable.bg_chip_on else R.drawable.bg_chip_off)
    }

    private fun append(c: Char) { number.append(c); refresh(); numberView.pop() }

    private fun refresh() {
        numberView.text = number.toString()
        val digits = number.toString()
        suggestion = if (digits.length >= 3) contactCache.firstOrNull { it.number.contains(digits) } else null
        val s = suggestion
        if (s != null) {
            suggestView.text = "👤 ${s.title}  ·  ${s.sub}"
            suggestView.visibility = View.VISIBLE
        } else {
            suggestView.visibility = View.INVISIBLE
        }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun loadHistory() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        Thread {
            val rows = ArrayList<Row>()
            try {
                val cols = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE,
                    CallLog.Calls.DATE, CallLog.Calls.DURATION
                )
                contentResolver.query(
                    CallLog.Calls.CONTENT_URI, cols, null, null, "${CallLog.Calls.DATE} DESC"
                )?.use { c ->
                    val df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    while (c.moveToNext() && rows.size < 200) {
                        val num = c.getString(0) ?: ""
                        val name = c.getString(1)
                        val (label, kind) = when (c.getInt(2)) {
                            CallLog.Calls.INCOMING_TYPE -> Pair("↙ Incoming", 1)
                            CallLog.Calls.OUTGOING_TYPE -> Pair("↗ Outgoing", 2)
                            CallLog.Calls.MISSED_TYPE -> Pair("✖ Missed", 3)
                            CallLog.Calls.REJECTED_TYPE -> Pair("⊘ Rejected", 4)
                            else -> Pair("Call", 0)
                        }
                        val dur = c.getLong(4)
                        val durText = if (dur > 0) "  ·  %d:%02d".format(dur / 60, dur % 60) else ""
                        val title = if (!name.isNullOrBlank()) name else if (num.isBlank()) "Unknown" else num
                        rows.add(Row(title, "$label  ·  ${df.format(Date(c.getLong(3)))}$durText", num, kind))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { historyCache = rows; applyHistory() }
        }.start()
    }

    private fun applyHistory() {
        val rows = if (missedOnly) historyCache.filter { it.kind == 3 } else historyCache
        historyList.adapter = RowAdapter(this, rows)
    }

    private fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val rows = ArrayList<Row>()
            try {
                contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ),
                    null, null, "${ContactsContract.Contacts.DISPLAY_NAME} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(0) ?: continue
                        val num = c.getString(1) ?: continue
                        val clean = num.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
                        rows.add(Row(name, num, clean))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { contactCache = rows; applyContacts(); refresh() }
        }.start()
    }

    private fun applyContacts() {
        val q = searchBox.text.toString().trim().lowercase()
        val rows = if (q.isEmpty()) contactCache
        else contactCache.filter { it.title.lowercase().contains(q) || it.number.contains(q) }
        contactsList.adapter = RowAdapter(this, rows)
    }

    private fun isDefaultDialer(): Boolean =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    private fun placeCall(num: String) {
        if (num.isEmpty()) return
        if (!isDefaultDialer()) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                Toast.makeText(this, "Pehle is app ko default Phone app banao", Toast.LENGTH_LONG).show()
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
            return
        }
        if (!has(Manifest.permission.CALL_PHONE)) {
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE)); return
        }
        getSystemService(TelecomManager::class.java)
            .placeCall(Uri.fromParts("tel", num, null), Bundle())
    }
}
