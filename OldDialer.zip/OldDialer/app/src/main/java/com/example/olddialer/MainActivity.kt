package com.example.olddialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.telecom.TelecomManager
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged

class MainActivity : AppCompatActivity() {
    private lateinit var header: View
    private lateinit var headerTitle: TextView
    private lateinit var numberView: TextView
    private lateinit var suggestView: TextView
    private lateinit var btnAddContact: TextView
    private lateinit var btnBack: ImageView
    private lateinit var btnMsg: ImageView
    private lateinit var dialPane: View
    private lateinit var historyPane: View
    private lateinit var historyList: ListView
    private lateinit var contactsPane: View
    private lateinit var contactsList: ListView
    private lateinit var messagesPane: View
    private lateinit var msgList: ListView
    private lateinit var msgEmpty: TextView
    private lateinit var searchBox: EditText
    private lateinit var tabs: List<View>
    private lateinit var navPills: List<View>
    private lateinit var navIcons: List<ImageView>
    private lateinit var navLabels: List<TextView>

    private val number = StringBuilder()
    private var tab = 0
    private var suggestion: Row? = null
    private var historyCache: List<Row> = emptyList()
    private var contactCache: List<Row> = emptyList()
    private var tone: ToneGenerator? = null

    private val smsObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { loadConversations() }
    }
    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadContacts(); loadHistory(); loadConversations()
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        header = findViewById(R.id.header)
        headerTitle = findViewById(R.id.headerTitle)
        numberView = findViewById(R.id.numberView)
        suggestView = findViewById(R.id.suggestView)
        btnAddContact = findViewById(R.id.btnAddContact)
        btnBack = findViewById(R.id.btnBack)
        btnMsg = findViewById(R.id.btnMsg)
        dialPane = findViewById(R.id.dialPane)
        historyPane = findViewById(R.id.historyPane)
        historyList = findViewById(R.id.historyList)
        contactsPane = findViewById(R.id.contactsPane)
        contactsList = findViewById(R.id.contactsList)
        messagesPane = findViewById(R.id.messagesPane)
        msgList = findViewById(R.id.msgList)
        msgEmpty = findViewById(R.id.msgEmpty)
        searchBox = findViewById(R.id.searchBox)
        tabs = listOf(R.id.tab0, R.id.tab1, R.id.tab2, R.id.tab3).map { findViewById<View>(it) }
        navPills = listOf(R.id.navPill0, R.id.navPill1, R.id.navPill2, R.id.navPill3).map { findViewById<View>(it) }
        navIcons = listOf(R.id.navIcon0, R.id.navIcon1, R.id.navIcon2, R.id.navIcon3).map { findViewById<ImageView>(it) }
        navLabels = listOf(R.id.navLabel0, R.id.navLabel1, R.id.navLabel2, R.id.navLabel3).map { findViewById<TextView>(it) }
        try { tone = ToneGenerator(AudioManager.STREAM_DTMF, 80) } catch (e: Exception) { }

        buildKeypad()
        tabs.forEachIndexed { i, t -> t.setOnClickListener { selectTab(i) } }

        findViewById<View>(R.id.btnCall).setOnClickListener {
            it.pop()
            if (number.isEmpty()) {
                historyCache.firstOrNull { r -> r.kind == 2 }?.let { r ->
                    number.append(r.number); refresh()
                }
            } else placeCall(number.toString())
        }
        btnBack.setOnClickListener {
            if (number.isNotEmpty()) { number.deleteCharAt(number.length - 1); refresh() }
        }
        btnBack.setOnLongClickListener { number.clear(); refresh(); true }
        btnMsg.setOnClickListener { openThread(number.toString()) }
        suggestView.setOnClickListener {
            suggestion?.let { number.clear(); number.append(it.number); refresh() }
        }
        btnAddContact.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                    type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                    putExtra(ContactsContract.Intents.Insert.PHONE, number.toString())
                })
            } catch (e: Exception) { }
        }
        findViewById<View>(R.id.btnNewMsg).setOnClickListener { openThread("") }
        findViewById<View>(R.id.btnMenu).setOnClickListener { v ->
            PopupMenu(this, v).apply {
                menu.add(0, 1, 0, "Set as default phone app")
                menu.add(0, 2, 1, "Set as default messaging app")
                menu.add(0, 3, 2, "Call settings")
                menu.add(0, 4, 3, "Call recordings")
                menu.add(0, 5, 4, "Auto-record calls: ${if (Prefs.autoRecord(this@MainActivity)) "ON" else "OFF"}")
                setOnMenuItemClickListener {
                    when (it.itemId) {
                        1 -> requestRole(RoleManager.ROLE_DIALER)
                        2 -> requestRole(RoleManager.ROLE_SMS)
                        3 -> try { startActivity(Intent(TelecomManager.ACTION_SHOW_CALL_SETTINGS)) } catch (e: Exception) { }
                        4 -> startActivity(Intent(this@MainActivity, RecordingsActivity::class.java))
                        5 -> {
                            val on = !Prefs.autoRecord(this@MainActivity)
                            Prefs.setAutoRecord(this@MainActivity, on)
                            Toast.makeText(this@MainActivity, "Auto-record ${if (on) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                        }
                    }
                    true
                }
                show()
            }
        }
        searchBox.doAfterTextChanged { applyContacts() }

        for (lv in listOf(historyList, contactsList)) {
            lv.setOnItemClickListener { _, _, pos, _ ->
                (lv.adapter as? RowAdapter)?.getItem(pos)?.let { placeCall(it.number) }
            }
            lv.setOnItemLongClickListener { _, view, pos, _ ->
                (lv.adapter as? RowAdapter)?.getItem(pos)?.let { rowMenu(view, it) }
                true
            }
        }
        msgList.setOnItemClickListener { _, _, pos, _ ->
            (msgList.adapter as? RowAdapter)?.getItem(pos)?.let { openThread(it.number) }
        }
        msgList.setOnItemLongClickListener { _, view, pos, _ ->
            (msgList.adapter as? RowAdapter)?.getItem(pos)?.let { rowMenu(view, it) }
            true
        }

        permLauncher.launch(
            arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
        selectTab(0)
        loadContacts()
        loadHistory()
        loadConversations()
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, smsObserver)
    }

    override fun onStop() {
        super.onStop()
        contentResolver.unregisterContentObserver(smsObserver)
    }

    override fun onDestroy() {
        super.onDestroy()
        tone?.release()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        loadHistory()
        loadConversations()
    }

    private fun handleIntent(i: Intent?) {
        i?.data?.schemeSpecificPart?.let {
            number.clear(); number.append(Uri.decode(it)); selectTab(0)
        }
    }

    private fun openThread(addr: String) {
        startActivity(Intent(this, ThreadActivity::class.java).putExtra("address", addr))
    }

    private fun rowMenu(anchor: View, r: Row) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Call")
            menu.add(0, 2, 1, "Message")
            menu.add(0, 3, 2, "Copy to keypad")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> placeCall(r.number)
                    2 -> openThread(r.number)
                    3 -> { number.clear(); number.append(r.number); selectTab(0) }
                }
                true
            }
            show()
        }
    }

    private fun buildKeypad() {
        val keys = listOf(
            "1" to " ", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to " ", "0" to "+", "#" to " "
        )
        val grid = findViewById<LinearLayout>(R.id.keypadGrid)
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        val text = ContextCompat.getColor(this, R.color.c_text)
        val sub = ContextCompat.getColor(this, R.color.c_sub)
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            for (c in 0 until 3) {
                val (d, l) = keys[r * 3 + c]
                val key = LinearLayout(this)
                key.orientation = LinearLayout.VERTICAL
                key.gravity = Gravity.CENTER
                key.layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1f
                )
                key.isClickable = true
                key.setBackgroundResource(tv.resourceId)
                val dt = TextView(this)
                dt.text = d
                dt.textSize = 32f
                dt.setTextColor(text)
                dt.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                dt.gravity = Gravity.CENTER
                val lt = TextView(this)
                lt.text = l
                lt.textSize = 10f
                lt.letterSpacing = 0.1f
                lt.setTextColor(sub)
                lt.gravity = Gravity.CENTER
                key.addView(dt)
                key.addView(lt)
                key.setOnClickListener { append(d[0]) }
                if (d == "0") key.setOnLongClickListener { append('+'); true }
                row.addView(key)
            }
            grid.addView(row)
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        dialPane.visibility = if (i == 0) View.VISIBLE else View.GONE
        historyPane.visibility = if (i == 1) View.VISIBLE else View.GONE
        contactsPane.visibility = if (i == 2) View.VISIBLE else View.GONE
        messagesPane.visibility = if (i == 3) View.VISIBLE else View.GONE
        headerTitle.visibility = if (i == 0) View.GONE else View.VISIBLE
        headerTitle.text = listOf("", "Recents", "Contacts", "Messages")[i]
        header.layoutParams.height = dp(if (i == 0) 56 else 116)
        header.requestLayout()
        val main = ContextCompat.getColor(this, R.color.c_text)
        val grey = ContextCompat.getColor(this, R.color.c_sub)
        for (k in 0..3) {
            val col = if (k == i) main else grey
            navPills[k].setBackgroundResource(if (k == i) R.drawable.bg_nav_pill else 0)
            navIcons[k].setColorFilter(col)
            navLabels[k].setTextColor(col)
            navLabels[k].typeface = if (k == i) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        refresh()
        if (i == 1) loadHistory()
        if (i == 2) applyContacts()
        if (i == 3) loadConversations()
    }

    private fun append(c: Char) {
        number.append(c)
        refresh()
        val t = when (c) { '*' -> 10; '#' -> 11; '+' -> -1; else -> c - '0' }
        if (t >= 0) tone?.startTone(t, 100)
    }

    private fun refresh() {
        val digits = number.toString()
        numberView.text = digits
        btnBack.visibility = if (digits.isEmpty()) View.INVISIBLE else View.VISIBLE
        btnMsg.visibility = if (digits.isEmpty()) View.INVISIBLE else View.VISIBLE
        btnAddContact.visibility = if (digits.isEmpty()) View.GONE else View.VISIBLE
        suggestion = if (digits.length >= 3) contactCache.firstOrNull { it.number.contains(digits) } else null
        val s = suggestion
        if (s != null) {
            suggestView.text = "${s.title}  ·  ${s.sub}"
            suggestView.visibility = View.VISIBLE
        } else {
            suggestView.visibility = View.GONE
        }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun loadHistory() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        Thread {
            val rows = ArrayList<Row>()
            try {
                val cols = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE
                )
                contentResolver.query(
                    CallLog.Calls.CONTENT_URI, cols, null, null, "${CallLog.Calls.DATE} DESC"
                )?.use { c ->
                    while (c.moveToNext() && rows.size < 200) {
                        val num = c.getString(0) ?: ""
                        val name = c.getString(1)
                        val ms = c.getLong(3)
                        val (arrow, kind) = when (c.getInt(2)) {
                            CallLog.Calls.INCOMING_TYPE -> Pair("↙", 1)
                            CallLog.Calls.OUTGOING_TYPE -> Pair("↗", 2)
                            CallLog.Calls.MISSED_TYPE -> Pair("↙", 3)
                            CallLog.Calls.REJECTED_TYPE -> Pair("↙", 4)
                            else -> Pair("", 0)
                        }
                        val title = if (!name.isNullOrBlank()) name else if (num.isBlank()) "Unknown" else num
                        rows.add(Row(title, "$arrow ${if (num.isBlank()) "Unknown" else num}".trim(), num, kind, Ui.whenText(ms)))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { historyCache = rows; historyList.adapter = RowAdapter(this, rows) }
        }.start()
    }

    private fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val rows = ArrayList<Row>()
            try {
                contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ),
                    null, null, "${ContactsContract.Contacts.DISPLAY_NAME} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(0) ?: continue
                        val num = c.getString(1) ?: continue
                        val clean = num.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
                        rows.add(Row(name, num, clean))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { contactCache = rows; applyContacts(); refresh() }
        }.start()
    }

    private fun applyContacts() {
        val q = searchBox.text.toString().trim().lowercase()
        val rows = if (q.isEmpty()) contactCache
        else contactCache.filter { it.title.lowercase().contains(q) || it.number.contains(q) }
        contactsList.adapter = RowAdapter(this, rows)
    }

    private fun loadConversations() {
        if (!has(Manifest.permission.READ_SMS)) {
            msgEmpty.text = "SMS permission allow karo to messages dikhenge"
            msgEmpty.visibility = View.VISIBLE
            return
        }
        Thread {
            val rows = SmsStore.conversations(this).map { c ->
                val name = ContactUtils.nameFor(this, c.address)
                Row(
                    name ?: c.address.ifBlank { "Unknown" },
                    c.snippet.replace('\n', ' '), c.address, 0, Ui.whenText(c.date), c.unread
                )
            }
            runOnUiThread {
                msgList.adapter = RowAdapter(this, rows)
                msgEmpty.text = "No conversations"
                msgEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun requestRole(role: String) {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(role) && !rm.isRoleHeld(role)) {
            roleLauncher.launch(rm.createRequestRoleIntent(role))
        } else if (rm.isRoleHeld(role)) {
            Toast.makeText(this, "Pehle se default hai", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isDefaultDialer(): Boolean =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    private fun placeCall(num: String) {
        if (num.isEmpty()) return
        if (!isDefaultDialer()) {
            Toast.makeText(this, "Pehle is app ko default Phone app banao", Toast.LENGTH_LONG).show()
            requestRole(RoleManager.ROLE_DIALER)
            return
        }
        if (!has(Manifest.permission.CALL_PHONE)) {
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE)); return
        }
        getSystemService(TelecomManager::class.java)
            .placeCall(Uri.fromParts("tel", num, null), Bundle())
    }
}
