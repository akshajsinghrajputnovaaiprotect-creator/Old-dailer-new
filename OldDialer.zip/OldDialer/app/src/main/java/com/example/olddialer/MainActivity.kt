package com.example.olddialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.text.format.DateUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var headerTitle: TextView
    private lateinit var numberView: TextView
    private lateinit var suggestView: TextView
    private lateinit var btnAddContact: TextView
    private lateinit var btnBack: ImageView
    private lateinit var dialPane: View
    private lateinit var historyList: ListView
    private lateinit var contactsPane: View
    private lateinit var contactsList: ListView
    private lateinit var searchBox: EditText
    private lateinit var tabs: List<View>
    private lateinit var navIcons: List<ImageView>
    private lateinit var navLabels: List<TextView>

    private val number = StringBuilder()
    private var tab = 0
    private var suggestion: Row? = null
    private var historyCache: List<Row> = emptyList()
    private var contactCache: List<Row> = emptyList()
    private var tone: ToneGenerator? = null

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadContacts(); loadHistory()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        headerTitle = findViewById(R.id.headerTitle)
        numberView = findViewById(R.id.numberView)
        suggestView = findViewById(R.id.suggestView)
        btnAddContact = findViewById(R.id.btnAddContact)
        btnBack = findViewById(R.id.btnBack)
        dialPane = findViewById(R.id.dialPane)
        historyList = findViewById(R.id.historyList)
        contactsPane = findViewById(R.id.contactsPane)
        contactsList = findViewById(R.id.contactsList)
        searchBox = findViewById(R.id.searchBox)
        tabs = listOf(findViewById(R.id.tab0), findViewById(R.id.tab1), findViewById(R.id.tab2))
        navIcons = listOf(findViewById(R.id.navIcon0), findViewById(R.id.navIcon1), findViewById(R.id.navIcon2))
        navLabels = listOf(findViewById(R.id.navLabel0), findViewById(R.id.navLabel1), findViewById(R.id.navLabel2))
        try { tone = ToneGenerator(AudioManager.STREAM_DTMF, 80) } catch (e: Exception) { }

        buildKeypad()
        tabs.forEachIndexed { i, t -> t.setOnClickListener { selectTab(i) } }

        findViewById<View>(R.id.btnCall).setOnClickListener {
            if (number.isEmpty()) {
                historyCache.firstOrNull { it.kind == 2 }?.let {
                    number.append(it.number); refresh()
                }
            } else placeCall(number.toString())
        }
        btnBack.setOnClickListener {
            if (number.isNotEmpty()) { number.deleteCharAt(number.length - 1); refresh() }
        }
        btnBack.setOnLongClickListener { number.clear(); refresh(); true }
        suggestView.setOnClickListener {
            suggestion?.let { number.clear(); number.append(it.number); refresh() }
        }
        btnAddContact.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_INSERT_OR_EDIT).apply {
                    type = ContactsContract.Contacts.CONTENT_ITEM_TYPE
                    putExtra(ContactsContract.Intents.Insert.PHONE, number.toString())
                })
            } catch (e: Exception) { }
        }
        findViewById<View>(R.id.btnMenu).setOnClickListener { v ->
            PopupMenu(this, v).apply {
                menu.add(0, 1, 0, "Set as default phone app")
                menu.add(0, 2, 1, "Call settings")
                setOnMenuItemClickListener {
                    when (it.itemId) {
                        1 -> requestDialerRole()
                        2 -> try { startActivity(Intent(TelecomManager.ACTION_SHOW_CALL_SETTINGS)) } catch (e: Exception) { }
                    }
                    true
                }
                show()
            }
        }
        searchBox.doAfterTextChanged { applyContacts() }

        for (lv in listOf(historyList, contactsList)) {
            lv.setOnItemClickListener { _, _, pos, _ ->
                (lv.adapter as? RowAdapter)?.getItem(pos)?.let { placeCall(it.number) }
            }
            lv.setOnItemLongClickListener { _, _, pos, _ ->
                (lv.adapter as? RowAdapter)?.getItem(pos)?.let {
                    number.clear(); number.append(it.number); selectTab(0)
                }
                true
            }
        }

        permLauncher.launch(
            arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
        selectTab(0)
        loadContacts()
        loadHistory()
        handleIntent(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        tone?.release()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        loadHistory()
    }

    private fun handleIntent(i: Intent?) {
        i?.data?.schemeSpecificPart?.let {
            number.clear(); number.append(Uri.decode(it)); selectTab(0)
        }
    }

    private fun buildKeypad() {
        val keys = listOf(
            "1" to "oo", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to " ", "0" to "+", "#" to " "
        )
        val grid = findViewById<LinearLayout>(R.id.keypadGrid)
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        val text = ContextCompat.getColor(this, R.color.c_text)
        val sub = ContextCompat.getColor(this, R.color.c_sub)
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
            for (c in 0 until 3) {
                val (d, l) = keys[r * 3 + c]
                val key = LinearLayout(this)
                key.orientation = LinearLayout.VERTICAL
                key.gravity = Gravity.CENTER
                key.layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1f
                )
                key.isClickable = true
                key.setBackgroundResource(tv.resourceId)
                val dt = TextView(this)
                dt.text = d
                dt.textSize = 32f
                dt.setTextColor(text)
                dt.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                dt.gravity = Gravity.CENTER
                val lt = TextView(this)
                lt.text = l
                lt.textSize = 10f
                lt.letterSpacing = 0.12f
                lt.setTextColor(sub)
                lt.gravity = Gravity.CENTER
                key.addView(dt)
                key.addView(lt)
                key.setOnClickListener { append(d[0]) }
                if (d == "0") key.setOnLongClickListener { append('+'); true }
                row.addView(key)
            }
            grid.addView(row)
        }
    }

    private fun selectTab(i: Int) {
        tab = i
        dialPane.visibility = if (i == 0) View.VISIBLE else View.GONE
        historyList.visibility = if (i == 1) View.VISIBLE else View.GONE
        contactsPane.visibility = if (i == 2) View.VISIBLE else View.GONE
        headerTitle.visibility = if (i == 0) View.GONE else View.VISIBLE
        headerTitle.text = if (i == 1) "Recents" else "Contacts"
        val blue = ContextCompat.getColor(this, R.color.c_blue)
        val grey = ContextCompat.getColor(this, R.color.c_sub)
        for (k in 0..2) {
            val col = if (k == i) blue else grey
            navIcons[k].setColorFilter(col)
            navLabels[k].setTextColor(col)
            navLabels[k].typeface = if (k == i) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
        refresh()
        if (i == 1) loadHistory()
        if (i == 2) applyContacts()
    }

    private fun append(c: Char) {
        number.append(c)
        refresh()
        val t = when (c) { '*' -> 10; '#' -> 11; '+' -> -1; else -> c - '0' }
        if (t >= 0) tone?.startTone(t, 100)
    }

    private fun refresh() {
        val digits = number.toString()
        numberView.text = digits
        btnBack.visibility = if (digits.isEmpty()) View.INVISIBLE else View.VISIBLE
        btnAddContact.visibility = if (digits.isEmpty()) View.GONE else View.VISIBLE
        suggestion = if (digits.length >= 3) contactCache.firstOrNull { it.number.contains(digits) } else null
        val s = suggestion
        if (s != null) {
            suggestView.text = "${s.title}  ·  ${s.sub}"
            suggestView.visibility = View.VISIBLE
        } else {
            suggestView.visibility = View.GONE
        }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun loadHistory() {
        if (!has(Manifest.permission.READ_CALL_LOG)) return
        Thread {
            val rows = ArrayList<Row>()
            try {
                val cols = arrayOf(
                    CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE
                )
                contentResolver.query(
                    CallLog.Calls.CONTENT_URI, cols, null, null, "${CallLog.Calls.DATE} DESC"
                )?.use { c ->
                    val timeFmt = DateFormat.getTimeInstance(DateFormat.SHORT)
                    val dateFmt = SimpleDateFormat("d MMM", Locale.getDefault())
                    while (c.moveToNext() && rows.size < 200) {
                        val num = c.getString(0) ?: ""
                        val name = c.getString(1)
                        val ms = c.getLong(3)
                        val (arrow, kind) = when (c.getInt(2)) {
                            CallLog.Calls.INCOMING_TYPE -> Pair("↙", 1)
                            CallLog.Calls.OUTGOING_TYPE -> Pair("↗", 2)
                            CallLog.Calls.MISSED_TYPE -> Pair("↙", 3)
                            CallLog.Calls.REJECTED_TYPE -> Pair("↙", 4)
                            else -> Pair("", 0)
                        }
                        val title = if (!name.isNullOrBlank()) name else if (num.isBlank()) "Unknown" else num
                        val time = if (DateUtils.isToday(ms)) timeFmt.format(Date(ms)) else dateFmt.format(Date(ms))
                        rows.add(Row(title, "$arrow ${if (num.isBlank()) "Unknown" else num}".trim(), num, kind, time))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { historyCache = rows; historyList.adapter = RowAdapter(this, rows) }
        }.start()
    }

    private fun loadContacts() {
        if (!has(Manifest.permission.READ_CONTACTS)) return
        Thread {
            val rows = ArrayList<Row>()
            try {
                contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(
                        ContactsContract.Contacts.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    ),
                    null, null, "${ContactsContract.Contacts.DISPLAY_NAME} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val name = c.getString(0) ?: continue
                        val num = c.getString(1) ?: continue
                        val clean = num.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
                        rows.add(Row(name, num, clean))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { contactCache = rows; applyContacts(); refresh() }
        }.start()
    }

    private fun applyContacts() {
        val q = searchBox.text.toString().trim().lowercase()
        val rows = if (q.isEmpty()) contactCache
        else contactCache.filter { it.title.lowercase().contains(q) || it.number.contains(q) }
        contactsList.adapter = RowAdapter(this, rows)
    }

    private fun isDefaultDialer(): Boolean =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    private fun requestDialerRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        }
    }

    private fun placeCall(num: String) {
        if (num.isEmpty()) return
        if (!isDefaultDialer()) {
            Toast.makeText(this, "Pehle is app ko default Phone app banao", Toast.LENGTH_LONG).show()
            requestDialerRole()
            return
        }
        if (!has(Manifest.permission.CALL_PHONE)) {
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE)); return
        }
        getSystemService(TelecomManager::class.java)
            .placeCall(Uri.fromParts("tel", num, null), Bundle())
    }
}
