package com.example.olddialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var numberView: TextView
    private val number = StringBuilder()

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        numberView = findViewById(R.id.numberView)

        findViewById<RotaryDialView>(R.id.dial).apply {
            onDigit = { append(it) }
            onCenterTap = { placeCall() }
        }
        findViewById<TextView>(R.id.btnBack).apply {
            setOnClickListener { if (number.isNotEmpty()) { number.deleteCharAt(number.length - 1); refresh() } }
            setOnLongClickListener { number.clear(); refresh(); true }
        }
        findViewById<android.widget.Button>(R.id.btnStar).setOnClickListener { append('*') }
        findViewById<android.widget.Button>(R.id.btnHash).setOnClickListener { append('#') }
        findViewById<android.widget.Button>(R.id.btnPlus).setOnClickListener { append('+') }

        permLauncher.launch(
            arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS
            )
        )
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        i?.data?.schemeSpecificPart?.let { number.clear(); number.append(Uri.decode(it)); refresh() }
    }

    private fun append(c: Char) { number.append(c); refresh() }
    private fun refresh() { numberView.text = number }

    private fun isDefaultDialer(): Boolean =
        getSystemService(TelecomManager::class.java).defaultDialerPackage == packageName

    private fun placeCall() {
        if (number.isEmpty()) return
        if (!isDefaultDialer()) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                Toast.makeText(this, "Pehle is app ko default Phone app banao", Toast.LENGTH_LONG).show()
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
            return
        }
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE)); return
        }
        getSystemService(TelecomManager::class.java)
            .placeCall(Uri.fromParts("tel", number.toString(), null), Bundle())
    }
}
