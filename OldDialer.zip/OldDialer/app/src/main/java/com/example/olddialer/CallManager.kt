package com.example.olddialer

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

object CallManager {
    private val calls = mutableListOf<Call>()
    /** Jo call abhi screen par dikh rahi hai (sabse naya). */
    val call: Call? get() = calls.lastOrNull()
    private var service: InCallService? = null
    private var ringtone: Ringtone? = null
    private val listeners = mutableSetOf<() -> Unit>()

    private val callback = object : Call.Callback() {
        override fun onStateChanged(c: Call, state: Int) {
            if (state != Call.STATE_RINGING) stopRing()
            val s = service
            if (s != null) {
                if (state == Call.STATE_ACTIVE && Prefs.autoRecord(s) && !CallRecorder.isRecording) startRecording(s)
                if (state == Call.STATE_DISCONNECTING || state == Call.STATE_DISCONNECTED) stopRecording(s)
            }
            fireChanged()
        }
    }

    fun attach(c: Call, s: InCallService) {
        service = s
        calls.remove(c)
        calls.add(c)
        c.registerCallback(callback)
        if (c.state == Call.STATE_RINGING) startRing(s)
        fireChanged()
    }

    fun detach(c: Call) {
        c.unregisterCallback(callback)
        stopRing()
        calls.remove(c)
        if (calls.isEmpty()) service?.let { stopRecording(it) }
        fireChanged()
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun fireChanged() { listeners.toList().forEach { it() } }

    fun number(): String = call?.details?.handle?.schemeSpecificPart ?: "Unknown"

    fun answer() { stopRing(); call?.answer(VideoProfile.STATE_AUDIO_ONLY) }
    fun reject(message: String? = null) {
        stopRing()
        if (message != null) call?.reject(true, message) else call?.reject(false, null)
    }
    fun hangup() { stopRing(); call?.disconnect() }
    fun hold(on: Boolean) { if (on) call?.hold() else call?.unhold() }
    fun mute(on: Boolean) { service?.setMuted(on) }
    fun speaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
    }

    @Suppress("DEPRECATION")
    fun bluetoothAvailable(): Boolean {
        val mask = service?.callAudioState?.supportedRouteMask ?: 0
        return (mask and CallAudioState.ROUTE_BLUETOOTH) != 0
    }

    /** false = koi Bluetooth device connected nahi. */
    fun bluetooth(on: Boolean): Boolean {
        if (on && !bluetoothAvailable()) return false
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_BLUETOOTH else CallAudioState.ROUTE_EARPIECE)
        return true
    }

    fun startRecording(ctx: Context): Boolean {
        val who = ContactUtils.nameFor(ctx, number()) ?: number()
        val ok = CallRecorder.start(ctx, who)
        fireChanged()
        return ok
    }

    fun stopRecording(ctx: Context) {
        CallRecorder.stop(ctx)
        fireChanged()
    }

    private fun startRing(ctx: Context) {
        stopRing()
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = RingtoneManager.getRingtone(ctx, uri)?.apply {
            audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            isLooping = true
            play()
        }
    }

    private fun stopRing() { ringtone?.stop(); ringtone = null }
}
