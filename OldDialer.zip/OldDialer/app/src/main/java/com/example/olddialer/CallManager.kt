package com.example.olddialer

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile

object CallManager {
    var call: Call? = null
        private set
    private var service: InCallService? = null
    private var ringtone: Ringtone? = null
    private val listeners = mutableSetOf<() -> Unit>()

    private val callback = object : Call.Callback() {
        override fun onStateChanged(c: Call, state: Int) {
            if (state != Call.STATE_RINGING) stopRing()
            notifyAll()
        }
    }

    fun attach(c: Call, s: InCallService) {
        call = c; service = s
        c.registerCallback(callback)
        if (c.state == Call.STATE_RINGING) startRing(s)
        notifyAll()
    }

    fun detach(c: Call) {
        c.unregisterCallback(callback)
        stopRing()
        if (call == c) call = null
        notifyAll()
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun notifyAll() { listeners.toList().forEach { it() } }

    fun number(): String = call?.details?.handle?.schemeSpecificPart ?: "Unknown"

    fun answer() { stopRing(); call?.answer(VideoProfile.STATE_AUDIO_ONLY) }
    fun reject() { stopRing(); call?.reject(false, null) }
    fun hangup() { stopRing(); call?.disconnect() }
    fun mute(on: Boolean) { service?.setMuted(on) }
    fun speaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_EARPIECE)
    }

    private fun startRing(ctx: Context) {
        stopRing()
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = RingtoneManager.getRingtone(ctx, uri)?.apply {
            audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            isLooping = true
            play()
        }
    }

    private fun stopRing() { ringtone?.stop(); ringtone = null }
}
