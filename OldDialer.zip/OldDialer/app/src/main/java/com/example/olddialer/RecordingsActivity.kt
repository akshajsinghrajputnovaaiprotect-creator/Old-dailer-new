package com.example.olddialer

import android.content.ContentUris
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri

/** Saved call recordings ki list: tap = play, long-press = delete. */
class RecordingsActivity : AppCompatActivity() {
    private lateinit var list: ListView
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recordings)
        list = findViewById(R.id.recList)
        empty = findViewById(R.id.recEmpty)
        findViewById<View>(R.id.btnRecBack).setOnClickListener { finish() }
        list.setOnItemClickListener { _, _, pos, _ ->
            (list.adapter as? RowAdapter)?.getItem(pos)?.let { play(it.number) }
        }
        list.setOnItemLongClickListener { _, v, pos, _ ->
            (list.adapter as? RowAdapter)?.getItem(pos)?.let { r ->
                PopupMenu(this, v).apply {
                    menu.add(0, 1, 0, "Play")
                    menu.add(0, 2, 1, "Delete")
                    setOnMenuItemClickListener {
                        if (it.itemId == 1) play(r.number) else delete(r.number)
                        true
                    }
                    show()
                }
            }
            true
        }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun load() {
        Thread {
            val rows = ArrayList<Row>()
            try {
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.DATE_ADDED),
                    "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?", arrayOf("${CallRecorder.FOLDER}%"),
                    "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                        rows.add(Row(c.getString(1) ?: "Unknown", "Call recording", uri.toString(), 0, Ui.whenText(c.getLong(2) * 1000)))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread {
                list.adapter = RowAdapter(this, rows)
                empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun play(uri: String) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri.toUri(), "audio/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Koi audio player nahi mila", Toast.LENGTH_SHORT).show()
        }
    }

    private fun delete(uri: String) {
        try { contentResolver.delete(uri.toUri(), null, null) } catch (e: Exception) {
            Toast.makeText(this, "Delete nahi hui", Toast.LENGTH_SHORT).show()
        }
        load()
    }
}
