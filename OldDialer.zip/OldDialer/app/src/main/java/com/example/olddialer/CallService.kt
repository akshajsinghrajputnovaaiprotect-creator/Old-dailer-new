package com.example.olddialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService
import androidx.core.app.NotificationCompat

class CallService : InCallService() {
    private val channelId = "incoming_calls"
    private val notifId = 101

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.attach(call, this)
        val intent = Intent(this, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (call.state == Call.STATE_RINGING) showIncoming(intent) else startActivity(intent)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.detach(call)
        getSystemService(NotificationManager::class.java).cancel(notifId)
    }

    private fun showIncoming(intent: Intent) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Incoming calls", NotificationManager.IMPORTANCE_HIGH)
                .apply { setSound(null, null) } // ringtone CallManager bajata hai
        )
        val pi = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_call)
            .setContentTitle("Incoming call")
            .setContentText(CallManager.number())
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        nm.notify(notifId, n)
    }
}
