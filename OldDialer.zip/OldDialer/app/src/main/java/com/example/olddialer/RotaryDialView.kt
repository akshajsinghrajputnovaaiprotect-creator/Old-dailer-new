package com.example.olddialer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.*

/** Rotary dial: finger ko digit pe rakho, clockwise finger-stop tak ghumao, chhodo -> digit dial. */
class RotaryDialView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var onDigit: ((Char) -> Unit)? = null
    var onCenterTap: (() -> Unit)? = null

    private val stopAngle = 45f      // finger stop (neeche-right), degrees, clockwise from 3 o'clock
    private val holeStep = 32f
    private var dialAngle = 0f
    private var activeDigit = -1
    private var lastAng = 0f
    private var centerDown = false
    private var animator: ValueAnimator? = null

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF454545.toInt() }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFF8A8A8A.toInt()
    }
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF777777.toInt() }
    private val holeEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFF2A2A2A.toInt()
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.SERIF
    }
    private val center = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3A3A.toInt() }
    private val stop = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFFB8B8B8.toInt(); strokeCap = Paint.Cap.ROUND
    }
    private val icon = ContextCompat.getDrawable(ctx, R.drawable.ic_call)!!.mutate().apply {
        setTint(0xFF7A9A2A.toInt())
    }

    private var cx = 0f; private var cy = 0f
    private var radius = 0f; private var ringR = 0f; private var holeR = 0f; private var centerR = 0f

    private fun holeAngle(d: Int): Float { val n = if (d == 0) 10 else d; return -5f - (n - 1) * holeStep }
    private fun maxRot(d: Int): Float = (((stopAngle - holeAngle(d)) % 360f) + 360f) % 360f
    private fun norm(a: Float): Float {
        var x = a % 360f
        if (x > 180f) x -= 360f
        if (x <= -180f) x += 360f
        return x
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f
        radius = min(w, h) / 2f - 4f
        ringR = radius * 0.72f; holeR = radius * 0.155f; centerR = radius * 0.46f
        rim.strokeWidth = radius * 0.03f
        holeEdge.strokeWidth = holeR * 0.07f
        text.textSize = holeR * 1.15f
        stop.strokeWidth = holeR * 0.55f
    }

    override fun onDraw(c: Canvas) {
        c.drawCircle(cx, cy, radius, body)
        c.drawCircle(cx, cy, radius, rim)
        for (d in 0..9) {
            val a = Math.toRadians((holeAngle(d) + dialAngle).toDouble())
            val hx = cx + ringR * cos(a).toFloat()
            val hy = cy + ringR * sin(a).toFloat()
            c.drawCircle(hx, hy, holeR, hole)
            c.drawCircle(hx, hy, holeR, holeEdge)
            c.drawText(d.toString(), hx, hy - (text.ascent() + text.descent()) / 2f, text)
        }
        c.drawCircle(cx, cy, centerR, center)
        val s = (centerR * 0.9f).toInt()
        icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
        icon.draw(c)
        val r = RectF(cx - ringR, cy - ringR, cx + ringR, cy + ringR)
        c.drawArc(r, stopAngle - 14f, 28f, false, stop)
    }

    private fun hitDigit(x: Float, y: Float): Int {
        for (d in 0..9) {
            val a = Math.toRadians(holeAngle(d).toDouble())
            val hx = cx + ringR * cos(a).toFloat()
            val hy = cy + ringR * sin(a).toFloat()
            if (hypot(x - hx, y - hy) < holeR * 1.3f) return d
        }
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dx = e.x - cx; val dy = e.y - cy
        val ang = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animator?.cancel(); dialAngle = 0f; invalidate()
                if (hypot(dx, dy) < centerR) { centerDown = true; return true }
                val d = hitDigit(e.x, e.y)
                if (d < 0) return false
                activeDigit = d; lastAng = ang
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> if (activeDigit >= 0) {
                val delta = norm(ang - lastAng); lastAng = ang
                dialAngle = (dialAngle + delta).coerceIn(0f, maxRot(activeDigit))
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (centerDown) {
                    centerDown = false
                    if (hypot(dx, dy) < centerR) onCenterTap?.invoke()
                } else if (activeDigit >= 0) {
                    val d = activeDigit; activeDigit = -1
                    val reached = dialAngle >= maxRot(d) - 8f
                    returnDial()
                    if (reached) onDigit?.invoke('0' + d)
                }
            }
            MotionEvent.ACTION_CANCEL -> { centerDown = false; activeDigit = -1; returnDial() }
        }
        return true
    }

    private fun returnDial() {
        animator = ValueAnimator.ofFloat(dialAngle, 0f).apply {
            duration = (dialAngle * 3f).toLong().coerceAtLeast(150L)
            addUpdateListener { dialAngle = it.animatedValue as Float; invalidate() }
            start()
        }
    }
}
