package com.example.olddialer

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.*

/** Neon rotary dial: finger ko digit pe rakho, clockwise finger-stop tak ghumao, chhodo -> digit dial. */
class RotaryDialView @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {

    var onDigit: ((Char) -> Unit)? = null
    var onCenterTap: (() -> Unit)? = null

    private val stopAngle = 45f
    private val holeStep = 32f
    private var dialAngle = 0f
    private var activeDigit = -1
    private var lastAng = 0f
    private var centerDown = false
    private var atStop = false
    private var animator: ValueAnimator? = null

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1B1536.toInt() }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFFFF2E93.toInt()
    }
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF2E2557.toInt() }
    private val holeActive = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF2E93.toInt() }
    private val holeEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFF00E5FF.toInt()
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val center = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF120E26.toInt() }
    private val centerEdge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFFB6FF3B.toInt()
    }
    private val stop = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt(); strokeCap = Paint.Cap.ROUND
    }
    private val icon = ContextCompat.getDrawable(ctx, R.drawable.ic_call)!!.mutate().apply {
        setTint(0xFFB6FF3B.toInt())
    }

    private var cx = 0f; private var cy = 0f
    private var radius = 0f; private var ringR = 0f; private var holeR = 0f; private var centerR = 0f

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    private fun holeAngle(d: Int): Float { val n = if (d == 0) 10 else d; return -5f - (n - 1) * holeStep }
    private fun maxRot(d: Int): Float = (((stopAngle - holeAngle(d)) % 360f) + 360f) % 360f
    private fun norm(a: Float): Float {
        var x = a % 360f
        if (x > 180f) x -= 360f
        if (x <= -180f) x += 360f
        return x
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f
        radius = min(w, h) / 2f - 10f
        ringR = radius * 0.72f; holeR = radius * 0.155f; centerR = radius * 0.46f
        rim.strokeWidth = radius * 0.035f
        rim.setShadowLayer(radius * 0.06f, 0f, 0f, 0xFFFF2E93.toInt())
        holeEdge.strokeWidth = holeR * 0.08f
        centerEdge.strokeWidth = radius * 0.02f
        centerEdge.setShadowLayer(radius * 0.04f, 0f, 0f, 0xFFB6FF3B.toInt())
        text.textSize = holeR * 1.1f
        stop.strokeWidth = holeR * 0.5f
    }

    override fun onDraw(c: Canvas) {
        c.drawCircle(cx, cy, radius, body)
        c.drawCircle(cx, cy, radius, rim)
        for (d in 0..9) {
            val a = Math.toRadians((holeAngle(d) + dialAngle).toDouble())
            val hx = cx + ringR * cos(a).toFloat()
            val hy = cy + ringR * sin(a).toFloat()
            c.drawCircle(hx, hy, holeR, if (d == activeDigit) holeActive else hole)
            c.drawCircle(hx, hy, holeR, holeEdge)
            c.drawText(d.toString(), hx, hy - (text.ascent() + text.descent()) / 2f, text)
        }
        c.drawCircle(cx, cy, centerR, center)
        c.drawCircle(cx, cy, centerR, centerEdge)
        val s = (centerR * 0.9f).toInt()
        icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
        icon.draw(c)
        val r = RectF(cx - ringR, cy - ringR, cx + ringR, cy + ringR)
        c.drawArc(r, stopAngle - 14f, 28f, false, stop)
    }

    private fun hitDigit(x: Float, y: Float): Int {
        for (d in 0..9) {
            val a = Math.toRadians(holeAngle(d).toDouble())
            val hx = cx + ringR * cos(a).toFloat()
            val hy = cy + ringR * sin(a).toFloat()
            if (hypot(x - hx, y - hy) < holeR * 1.3f) return d
        }
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dx = e.x - cx; val dy = e.y - cy
        val ang = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animator?.cancel(); dialAngle = 0f; atStop = false; invalidate()
                if (hypot(dx, dy) < centerR) { centerDown = true; return true }
                val d = hitDigit(e.x, e.y)
                if (d < 0) return false
                activeDigit = d; lastAng = ang
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                parent?.requestDisallowInterceptTouchEvent(true)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> if (activeDigit >= 0) {
                val delta = norm(ang - lastAng); lastAng = ang
                val m = maxRot(activeDigit)
                dialAngle = (dialAngle + delta).coerceIn(0f, m)
                val now = dialAngle >= m - 1f
                if (now && !atStop) { atStop = true; performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
                else if (!now) atStop = false
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (centerDown) {
                    centerDown = false
                    if (hypot(dx, dy) < centerR) onCenterTap?.invoke()
                } else if (activeDigit >= 0) {
                    val d = activeDigit
                    val reached = dialAngle >= maxRot(d) - 8f
                    activeDigit = -1
                    returnDial()
                    if (reached) onDigit?.invoke('0' + d)
                }
            }
            MotionEvent.ACTION_CANCEL -> { centerDown = false; activeDigit = -1; returnDial() }
        }
        return true
    }

    private fun returnDial() {
        animator = ValueAnimator.ofFloat(dialAngle, 0f).apply {
            duration = (dialAngle * 3f).toLong().coerceAtLeast(150L)
            addUpdateListener { dialAngle = it.animatedValue as Float; invalidate() }
            start()
        }
    }
}
