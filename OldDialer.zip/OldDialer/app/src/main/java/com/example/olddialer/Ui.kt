package com.example.olddialer

import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.animation.OvershootInterpolator

object Ui {
    private val colors = intArrayOf(
        0xFF7E94B8.toInt(), 0xFF8FA3A0.toInt(), 0xFFB39BC8.toInt(),
        0xFFC9A48E.toInt(), 0xFF8AAE92.toInt(), 0xFF9AA5B1.toInt()
    )

    fun avatarBg(key: String): GradientDrawable {
        val c = colors[(key.hashCode() and 0x7fffffff) % colors.size]
        return GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    }

    fun initial(s: String): String {
        val c = s.firstOrNull { it.isLetter() }
        return c?.uppercase() ?: "#"
    }
}

fun View.pop() {
    animate().cancel()
    scaleX = 0.9f
    scaleY = 0.9f
    animate().scaleX(1f).scaleY(1f).setDuration(220)
        .setInterpolator(OvershootInterpolator(2f)).start()
}
