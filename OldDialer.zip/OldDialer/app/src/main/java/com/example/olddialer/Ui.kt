package com.example.olddialer

import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.animation.OvershootInterpolator

object Ui {
    private val pairs = arrayOf(
        intArrayOf(0xFFFF2E93.toInt(), 0xFF7B2FF7.toInt()),
        intArrayOf(0xFF00E5FF.toInt(), 0xFF3A86FF.toInt()),
        intArrayOf(0xFFB6FF3B.toInt(), 0xFF06D6A0.toInt()),
        intArrayOf(0xFFFFB703.toInt(), 0xFFFF4D6D.toInt()),
        intArrayOf(0xFFB388FF.toInt(), 0xFF5E60CE.toInt())
    )

    fun avatarBg(key: String): GradientDrawable {
        val p = pairs[(key.hashCode() and 0x7fffffff) % pairs.size]
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, p).apply {
            shape = GradientDrawable.OVAL
        }
    }

    fun initial(s: String): String {
        val c = s.firstOrNull { it.isLetter() }
        return c?.uppercase() ?: "#"
    }
}

fun View.pop() {
    animate().cancel()
    scaleX = 0.86f
    scaleY = 0.86f
    animate().scaleX(1f).scaleY(1f).setDuration(280)
        .setInterpolator(OvershootInterpolator(3f)).start()
}
