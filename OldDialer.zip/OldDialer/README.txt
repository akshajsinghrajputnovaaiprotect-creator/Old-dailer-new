OldDialer - Samsung One UI style Phone + Messages (Kotlin)
Tabs: Keypad / Recents / Contacts / Messages. One UI in-call + incoming call screen (quick reply SMS).
Messages: conversation list, chat bubbles, naya message (contact picker), SMS receive + notification.
GitHub Actions se build: workflow .github/workflows/build.yml (repo me upload karo).
Pehli baar: menu (3 dots) se "Set as default phone app" aur "Set as default messaging app" dono karo.
Note: sirf SMS support hai, MMS (photo/group) abhi nahi.
Call recording: mic se record hoti hai (speaker on rakho). Files: Music/CallRecordings. Menu me "Auto-record calls" bhi hai.
