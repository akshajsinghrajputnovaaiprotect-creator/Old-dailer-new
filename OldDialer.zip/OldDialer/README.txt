OldDialer - neon rotary dialer (Kotlin)
Dial / Recents / People tabs, neon in-call screen, incoming call screen, app logo.
GitHub Actions se build: workflow .github/workflows/build.yml (repo me upload karo).
Pehli baar app ko Default Phone app banao.
