OldDialer - rotary dialer app (Kotlin)
1. Android Studio me "Open" -> OldDialer folder. Gradle sync hone do.
2. Phone pe run karo (SIM wala real phone, emulator pe calls nahi chalenge).
3. Dial ghumake number banao, beech ke hare phone icon pe tap = call.
4. Pehli baar: app ko "Default Phone app" bana do (popup aayega). Tabhi apni calling aur incoming screen aayegi.
