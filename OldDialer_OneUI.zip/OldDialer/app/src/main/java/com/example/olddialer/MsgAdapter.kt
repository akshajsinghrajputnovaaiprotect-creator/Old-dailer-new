package com.example.olddialer

import android.content.Context
import android.text.format.DateUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MsgAdapter(private val ctx: Context, private val items: List<Msg>) : BaseAdapter() {
    private val timeFmt = DateFormat.getTimeInstance(DateFormat.SHORT)
    private val dayFmt = SimpleDateFormat("d MMM, ", Locale.getDefault())

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()
    override fun getViewTypeCount() = 2
    override fun getItemViewType(position: Int) = if (items[position].outgoing) 1 else 0

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val m = items[position]
        val v = convertView ?: LayoutInflater.from(ctx).inflate(
            if (m.outgoing) R.layout.item_msg_out else R.layout.item_msg_in, parent, false
        )
        v.findViewById<TextView>(R.id.msgBody).text = m.body
        val t = v.findViewById<TextView>(R.id.msgTime)
        val d = Date(m.date)
        t.text = if (m.failed) "Not sent" else (if (DateUtils.isToday(m.date)) "" else dayFmt.format(d)) + timeFmt.format(d)
        t.setTextColor(ContextCompat.getColor(ctx, if (m.failed) R.color.c_red else R.color.c_sub))
        return v
    }
}
