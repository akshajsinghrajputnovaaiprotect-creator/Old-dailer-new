package com.example.olddialer

import android.content.ContentValues
import android.content.Context
import android.provider.Telephony

data class Conv(
    val threadId: Long, val address: String, val snippet: String,
    val date: Long, val unread: Boolean
)

data class Msg(val body: String, val date: Long, val outgoing: Boolean, val failed: Boolean = false)

object SmsStore {
    fun isDefault(ctx: Context): Boolean = try {
        Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName
    } catch (e: Exception) { false }

    fun conversations(ctx: Context): List<Conv> {
        val out = LinkedHashMap<Long, Conv>()
        val unread = HashSet<Long>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(
                    Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY,
                    Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ
                ),
                null, null, "${Telephony.Sms.DATE} DESC"
            )?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 8000) {
                    n++
                    val tid = c.getLong(0)
                    if (c.getInt(4) == Telephony.Sms.MESSAGE_TYPE_INBOX && c.getInt(5) == 0) unread.add(tid)
                    if (!out.containsKey(tid) && out.size < 300) {
                        out[tid] = Conv(tid, c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), false)
                    }
                }
            }
        } catch (e: Exception) { }
        return out.values.map { it.copy(unread = unread.contains(it.threadId)) }
    }

    fun thread(ctx: Context, threadId: Long): List<Msg> {
        val list = ArrayList<Msg>()
        try {
            ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
                "${Telephony.Sms.THREAD_ID} = ?", arrayOf(threadId.toString()),
                "${Telephony.Sms.DATE} ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val type = c.getInt(2)
                    list.add(
                        Msg(
                            c.getString(0) ?: "", c.getLong(1),
                            outgoing = type != Telephony.Sms.MESSAGE_TYPE_INBOX,
                            failed = type == Telephony.Sms.MESSAGE_TYPE_FAILED
                        )
                    )
                }
            }
        } catch (e: Exception) { }
        return list
    }

    fun threadIdFor(ctx: Context, address: String): Long = try {
        Telephony.Threads.getOrCreateThreadId(ctx, address)
    } catch (e: Exception) { -1L }

    /** Sirf default SMS app hone par kaam karta hai. */
    fun markRead(ctx: Context, threadId: Long) {
        try {
            val v = ContentValues().apply { put(Telephony.Sms.READ, 1); put(Telephony.Sms.SEEN, 1) }
            ctx.contentResolver.update(
                Telephony.Sms.CONTENT_URI, v,
                "${Telephony.Sms.THREAD_ID} = ? AND ${Telephony.Sms.READ} = 0", arrayOf(threadId.toString())
            )
        } catch (e: Exception) { }
    }
}
