package com.example.olddialer

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager

object SmsSender {
    fun send(ctx: Context, to: String, text: String): Boolean {
        return try {
            @Suppress("DEPRECATION")
            val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
            else SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            if (parts.size > 1) sm.sendMultipartTextMessage(to, null, parts, null, null)
            else sm.sendTextMessage(to, null, text, null, null)
            // Default SMS app ho to provider me sent message khud likhna padta hai
            if (SmsStore.isDefault(ctx)) {
                val v = ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, to)
                    put(Telephony.Sms.BODY, text)
                    put(Telephony.Sms.DATE, System.currentTimeMillis())
                    put(Telephony.Sms.READ, 1)
                    put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_SENT)
                }
                try { ctx.contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, v) } catch (e: Exception) { }
            }
            true
        } catch (e: Exception) { false }
    }
}
