package com.example.olddialer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object Notifier {
    private const val CH = "messages"

    fun message(ctx: Context, address: String, body: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Messages", NotificationManager.IMPORTANCE_HIGH))
        val i = Intent(ctx, ThreadActivity::class.java)
            .putExtra("address", address)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, address.hashCode(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val name = ContactUtils.nameFor(ctx, address) ?: address
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_message)
            .setContentTitle(name)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setColor(0xFF3E91FF.toInt())
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(address.hashCode(), n)
    }

    fun cancel(ctx: Context, address: String) {
        ctx.getSystemService(NotificationManager::class.java).cancel(address.hashCode())
    }
}
