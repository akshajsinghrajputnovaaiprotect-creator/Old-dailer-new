package com.example.olddialer

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat

/** kind: 0 normal, 1 incoming, 2 outgoing, 3 missed, 4 rejected */
data class Row(
    val title: String, val sub: String, val number: String,
    val kind: Int = 0, val time: String = "", val unread: Boolean = false
)

class RowAdapter(ctx: Context, rows: List<Row>) : ArrayAdapter<Row>(ctx, 0, rows) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView
            ?: LayoutInflater.from(context).inflate(R.layout.item_row, parent, false)
        val r = getItem(position)
        val title = r?.title ?: ""
        val av = v.findViewById<TextView>(R.id.avatar)
        if (Ui.hasLetter(title)) {
            av.text = Ui.initial(title)
            av.background = Ui.avatarBg(title)
        } else {
            av.text = ""
            av.setBackgroundResource(R.drawable.bg_avatar_default)
        }
        val unread = r?.unread == true
        val t = v.findViewById<TextView>(R.id.rowTitle)
        t.text = title
        val missed = r?.kind == 3 || r?.kind == 4
        t.setTextColor(ContextCompat.getColor(context, if (missed) R.color.c_red else R.color.c_text))
        t.typeface = if (unread) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.DEFAULT
        val sub = v.findViewById<TextView>(R.id.rowSub)
        sub.text = r?.sub ?: ""
        sub.visibility = if (r?.sub.isNullOrEmpty()) View.GONE else View.VISIBLE
        sub.setTextColor(ContextCompat.getColor(context, if (missed) R.color.c_red else R.color.c_sub))
        val tm = v.findViewById<TextView>(R.id.rowTime)
        tm.text = r?.time ?: ""
        tm.setTextColor(ContextCompat.getColor(context, if (unread) R.color.c_blue else R.color.c_sub))
        v.findViewById<View>(R.id.rowDot).visibility = if (unread) View.VISIBLE else View.GONE
        return v
    }
}
