package com.example.olddialer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged

/** One UI style chat screen: bubbles + compose bar. Naya message ho to "To" box dikhta hai. */
class ThreadActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var compose: EditText
    private lateinit var btnSend: ImageView
    private lateinit var title: TextView
    private lateinit var toRow: View
    private lateinit var toBox: EditText

    private var address = ""
    private var threadId = -1L
    private val local = ArrayList<Msg>() // default SMS app na hone par bheje hue msgs
    private val handler = Handler(Looper.getMainLooper())
    private val observer = object : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) { load() }
    }

    private val smsPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) send() else Toast.makeText(this, "SMS permission chahiye", Toast.LENGTH_SHORT).show()
        }
    private val picker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val u = r.data?.data
            if (u != null) {
                try {
                    contentResolver.query(
                        u, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null
                    )?.use { if (it.moveToFirst()) toBox.setText(it.getString(0)) }
                } catch (e: Exception) { }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thread)
        listView = findViewById(R.id.msgListView)
        compose = findViewById(R.id.compose)
        btnSend = findViewById(R.id.btnSend)
        title = findViewById(R.id.threadTitle)
        toRow = findViewById(R.id.toRow)
        toBox = findViewById(R.id.toBox)

        findViewById<View>(R.id.btnThreadBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnThreadCall).setOnClickListener { callNow() }
        findViewById<View>(R.id.btnPick).setOnClickListener {
            picker.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
        }
        compose.doAfterTextChanged { btnSend.alpha = if (it.isNullOrBlank()) 0.4f else 1f }
        btnSend.setOnClickListener { send() }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        threadId = -1L
        local.clear()
        handleIntent(intent)
        load()
    }

    override fun onStart() {
        super.onStart()
        contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, observer)
    }

    override fun onStop() {
        super.onStop()
        contentResolver.unregisterContentObserver(observer)
    }

    override fun onResume() {
        super.onResume()
        if (address.isNotBlank()) Notifier.cancel(this, address)
        load()
    }

    private fun handleIntent(i: Intent) {
        val raw = i.getStringExtra("address")
            ?: i.data?.schemeSpecificPart?.substringBefore('?')?.let { Uri.decode(it) }
            ?: ""
        address = raw.split(',', ';').firstOrNull()?.trim() ?: ""
        val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT)
        if (!body.isNullOrEmpty()) compose.setText(body)
        showHeader()
    }

    private fun showHeader() {
        if (address.isBlank()) {
            toRow.visibility = View.VISIBLE
            title.text = "New message"
        } else {
            toRow.visibility = View.GONE
            title.text = ContactUtils.nameFor(this, address) ?: address
        }
    }

    private fun send() {
        val text = compose.text.toString().trim()
        if (text.isEmpty()) return
        val to = (if (address.isBlank()) toBox.text.toString() else address).trim()
        if (to.isEmpty()) {
            Toast.makeText(this, "Number daalo", Toast.LENGTH_SHORT).show(); return
        }
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            smsPerm.launch(Manifest.permission.SEND_SMS); return
        }
        if (!SmsSender.send(this, to, text)) {
            Toast.makeText(this, "Message nahi gaya", Toast.LENGTH_SHORT).show(); return
        }
        if (address.isBlank()) { address = to; showHeader() }
        if (!SmsStore.isDefault(this)) local.add(Msg(text, System.currentTimeMillis(), true))
        compose.setText("")
        load()
    }

    private fun load() {
        val addr = address
        if (addr.isBlank()) return
        Thread {
            if (threadId <= 0) threadId = SmsStore.threadIdFor(this, addr)
            val base = if (threadId > 0) SmsStore.thread(this, threadId) else emptyList()
            if (threadId > 0) SmsStore.markRead(this, threadId)
            val extra = local.filter { l ->
                base.none { it.outgoing && it.body == l.body && Math.abs(it.date - l.date) < 120_000 }
            }
            val merged = (base + extra).sortedBy { it.date }
            runOnUiThread {
                listView.adapter = MsgAdapter(this, merged)
                if (merged.isNotEmpty()) listView.setSelection(merged.size - 1)
            }
        }.start()
    }

    private fun callNow() {
        val num = (if (address.isBlank()) toBox.text.toString() else address).trim()
        if (num.isEmpty()) return
        val tm = getSystemService(TelecomManager::class.java)
        val canCall = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        if (tm.defaultDialerPackage == packageName && canCall) {
            tm.placeCall(Uri.fromParts("tel", num, null), Bundle())
        } else {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", num, null)))
        }
    }
}
