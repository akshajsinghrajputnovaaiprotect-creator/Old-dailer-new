package com.example.olddialer

import android.content.Context
import android.net.Uri
import android.provider.ContactsContract

object ContactUtils {
    fun nameFor(ctx: Context, number: String): String? {
        if (number.isBlank() || number == "Unknown") return null
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }
}
