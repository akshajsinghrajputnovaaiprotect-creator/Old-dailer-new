package com.example.olddialer

import android.graphics.drawable.GradientDrawable
import android.text.format.DateUtils
import android.view.View
import android.view.animation.OvershootInterpolator
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Ui {
    private val colors = intArrayOf(
        0xFF7E94B8.toInt(), 0xFF8FA3A0.toInt(), 0xFFB39BC8.toInt(),
        0xFFC9A48E.toInt(), 0xFF8AAE92.toInt(), 0xFF9AA5B1.toInt()
    )

    fun avatarBg(key: String): GradientDrawable {
        val c = colors[(key.hashCode() and 0x7fffffff) % colors.size]
        return GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    }

    /** Naam me koi letter hai? Nahi to default person icon dikhate hain. */
    fun hasLetter(s: String) = s.any { it.isLetter() }

    fun initial(s: String): String {
        val c = s.firstOrNull { it.isLetter() }
        return c?.uppercase() ?: ""
    }

    /** Aaj ho to time, warna "15 Nov". */
    fun whenText(ms: Long): String =
        if (DateUtils.isToday(ms)) DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(ms))
        else SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ms))
}

fun View.pop() {
    animate().cancel()
    scaleX = 0.92f
    scaleY = 0.92f
    animate().scaleX(1f).scaleY(1f).setDuration(200)
        .setInterpolator(OvershootInterpolator(2f)).start()
}
