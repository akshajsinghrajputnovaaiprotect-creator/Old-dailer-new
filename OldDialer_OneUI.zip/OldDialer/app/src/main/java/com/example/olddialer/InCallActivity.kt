package com.example.olddialer

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InCallActivity : AppCompatActivity() {
    private lateinit var root: View
    private lateinit var avatarBox: View
    private lateinit var avatar: TextView
    private lateinit var callNumber: TextView
    private lateinit var callSub: TextView
    private lateinit var status: TextView
    private lateinit var timer: TextView
    private lateinit var dtmfText: TextView
    private lateinit var keypadPanel: LinearLayout
    private lateinit var controlsRow: View
    private lateinit var btnEnd: View
    private lateinit var ringRow: View
    private lateinit var btnAnswer: View
    private lateinit var btnMute: ImageView
    private lateinit var btnSpeaker: ImageView
    private lateinit var btnKeypad: ImageView
    private lateinit var btnHold: ImageView
    private lateinit var btnQuickMsg: View
    private lateinit var spacer: View
    private lateinit var rings: List<View>

    private var muted = false
    private var speaker = false
    private var keypadOn = false
    private var lastBg = -1
    private var nameFor: String? = null
    private var nameKey: String? = null
    private var fastPulse: Boolean? = null
    private var bounce: ObjectAnimator? = null
    private val pulses = mutableListOf<ValueAnimator>()
    private val handler = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { render() }
    private val ticker = object : Runnable {
        override fun run() { updateTimer(); handler.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_in_call)
        root = findViewById(R.id.root)
        avatarBox = findViewById(R.id.avatarBox)
        avatar = findViewById(R.id.avatar)
        callNumber = findViewById(R.id.callNumber)
        callSub = findViewById(R.id.callSub)
        status = findViewById(R.id.callStatus)
        timer = findViewById(R.id.callTimer)
        dtmfText = findViewById(R.id.dtmfText)
        keypadPanel = findViewById(R.id.keypadPanel)
        controlsRow = findViewById(R.id.controlsRow)
        btnEnd = findViewById(R.id.btnEnd)
        ringRow = findViewById(R.id.ringRow)
        btnAnswer = findViewById(R.id.btnAnswer)
        btnMute = findViewById(R.id.btnMute)
        btnSpeaker = findViewById(R.id.btnSpeaker)
        btnKeypad = findViewById(R.id.btnKeypad)
        btnHold = findViewById(R.id.btnHold)
        btnQuickMsg = findViewById(R.id.btnQuickMsg)
        spacer = findViewById(R.id.spacer)
        rings = listOf(findViewById(R.id.ring1), findViewById(R.id.ring2), findViewById(R.id.ring3))

        btnAnswer.setOnClickListener { it.pop(); CallManager.answer() }
        findViewById<View>(R.id.btnReject).setOnClickListener { it.pop(); CallManager.reject() }
        btnEnd.setOnClickListener { it.pop(); CallManager.hangup() }
        btnMute.setOnClickListener {
            it.pop(); muted = !muted; CallManager.mute(muted); styleToggle(btnMute, muted)
        }
        btnSpeaker.setOnClickListener {
            it.pop(); speaker = !speaker; CallManager.speaker(speaker); styleToggle(btnSpeaker, speaker)
        }
        btnKeypad.setOnClickListener {
            it.pop(); keypadOn = !keypadOn; styleToggle(btnKeypad, keypadOn)
            keypadPanel.visibility = if (keypadOn) View.VISIBLE else View.GONE
            avatarBox.visibility = if (keypadOn) View.GONE else View.VISIBLE
            spacer.visibility = if (keypadOn) View.VISIBLE else View.GONE
        }
        btnHold.setOnClickListener {
            it.pop()
            val holding = CallManager.call?.state == Call.STATE_HOLDING
            CallManager.hold(!holding)
        }
        btnQuickMsg.setOnClickListener { v ->
            PopupMenu(this, v).apply {
                val replies = listOf(
                    "I can't talk right now. What's up?",
                    "I'll call you back in a bit.",
                    "Can you text me instead?"
                )
                replies.forEachIndexed { i, r -> menu.add(0, i, i, r) }
                setOnMenuItemClickListener { CallManager.reject(replies[it.itemId]); true }
                show()
            }
        }
        buildKeypad()
    }

    private fun styleToggle(v: ImageView, on: Boolean) {
        v.setBackgroundResource(if (on) R.drawable.bg_call_btn_on else R.drawable.bg_call_btn)
        v.setColorFilter(if (on) Color.parseColor("#111111") else Color.WHITE)
    }

    private fun buildKeypad() {
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER
            for (k in keys.subList(r * 3, r * 3 + 3)) {
                val tv = TextView(this)
                tv.text = k
                tv.textSize = 24f
                tv.setTextColor(Color.WHITE)
                tv.gravity = Gravity.CENTER
                tv.setBackgroundResource(R.drawable.bg_call_btn)
                val lp = LinearLayout.LayoutParams(dp(58), dp(58))
                lp.setMargins(dp(10), dp(4), dp(10), dp(4))
                tv.layoutParams = lp
                tv.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            CallManager.call?.playDtmfTone(k[0])
                            dtmfText.append(k)
                            v.pop()
                            true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            CallManager.call?.stopDtmfTone()
                            true
                        }
                        else -> false
                    }
                }
                row.addView(tv)
            }
            keypadPanel.addView(row)
        }
    }

    override fun onStart() {
        super.onStart()
        CallManager.addListener(listener)
        render()
        handler.post(ticker)
    }

    override fun onStop() {
        super.onStop()
        CallManager.removeListener(listener)
        handler.removeCallbacks(ticker)
        setPulse(null)
        setBounce(false)
    }

    private fun setPulse(fast: Boolean?) {
        if (fastPulse == fast && (fast == null || pulses.isNotEmpty())) return
        fastPulse = fast
        pulses.forEach { it.cancel() }
        pulses.clear()
        rings.forEach { it.alpha = 0f }
        if (fast == null) return
        rings.forEachIndexed { i, v ->
            val a = ValueAnimator.ofFloat(0f, 1f)
            a.duration = if (fast) 1800L else 3200L
            a.repeatCount = ValueAnimator.INFINITE
            a.startDelay = i * (if (fast) 600L else 1000L)
            a.interpolator = LinearInterpolator()
            a.addUpdateListener {
                val t = it.animatedValue as Float
                v.scaleX = 1f + t * 0.9f
                v.scaleY = 1f + t * 0.9f
                v.alpha = 0.55f * (1f - t)
            }
            a.start()
            pulses.add(a)
        }
    }

    private fun setBounce(on: Boolean) {
        if (on == (bounce != null)) return
        bounce?.cancel()
        bounce = null
        btnAnswer.translationY = 0f
        if (on) {
            val a = ObjectAnimator.ofFloat(btnAnswer, View.TRANSLATION_Y, 0f, -28f)
            a.duration = 550
            a.repeatMode = ValueAnimator.REVERSE
            a.repeatCount = ValueAnimator.INFINITE
            a.interpolator = AccelerateDecelerateInterpolator()
            a.start()
            bounce = a
        }
    }

    private fun setBg(res: Int) {
        if (lastBg == res) return
        lastBg = res
        root.setBackgroundResource(res)
    }

    private fun render() {
        val c = CallManager.call
        if (c == null) { finish(); return }
        val num = CallManager.number()
        if (nameKey != num) { nameKey = num; nameFor = ContactUtils.nameFor(this, num) }
        val name = nameFor
        callNumber.text = name ?: num
        callSub.text = if (name != null) num else ""
        if (name != null && Ui.hasLetter(name)) {
            avatar.text = Ui.initial(name)
            avatar.background = Ui.avatarBg(name)
        } else {
            avatar.text = ""
            avatar.setBackgroundResource(R.drawable.bg_avatar_default)
        }

        val ringing = c.state == Call.STATE_RINGING
        val ended = c.state == Call.STATE_DISCONNECTED || c.state == Call.STATE_DISCONNECTING
        ringRow.visibility = if (ringing) View.VISIBLE else View.GONE
        controlsRow.visibility = if (ringing) View.GONE else View.VISIBLE
        btnEnd.visibility = if (ringing) View.GONE else View.VISIBLE
        setBounce(ringing)
        styleToggle(btnHold, c.state == Call.STATE_HOLDING)

        when (c.state) {
            Call.STATE_RINGING -> { setBg(R.drawable.bg_call_ring); status.text = "Incoming call"; setPulse(true) }
            Call.STATE_DIALING, Call.STATE_CONNECTING -> { setBg(R.drawable.bg_call_ring); status.text = "Calling…"; setPulse(true) }
            Call.STATE_ACTIVE -> { setBg(R.drawable.bg_call_active); status.text = ""; setPulse(false) }
            Call.STATE_HOLDING -> { setBg(R.drawable.bg_call_active); status.text = "On hold"; setPulse(null) }
            else -> { setBg(R.drawable.bg_call_ended); status.text = "Call ended"; setPulse(null) }
        }
        status.visibility = if (status.text.isEmpty()) View.GONE else View.VISIBLE
        if (c.state == Call.STATE_DISCONNECTED) handler.postDelayed({ finish() }, 800)
        updateTimer()
    }

    private fun updateTimer() {
        val c = CallManager.call
        if (c == null || c.state != Call.STATE_ACTIVE) { timer.text = ""; return }
        val start = c.details.connectTimeMillis
        val s = ((System.currentTimeMillis() - start) / 1000).coerceAtLeast(0)
        timer.text = "%02d:%02d".format(s / 60, s % 60)
    }
}
